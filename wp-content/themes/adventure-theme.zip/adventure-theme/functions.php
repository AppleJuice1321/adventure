<?php
// Theme support
add_theme_support("custom-logo");
add_theme_support("post_thumbnails");

// Shortcodes